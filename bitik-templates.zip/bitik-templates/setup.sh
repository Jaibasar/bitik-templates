#!/bin/bash
# Бітік шаблон жүйесін орнату: қаріптер + қазақша тасымалдау
# Пайдалану: bash setup.sh
set -e

echo "1/4 — Шрифттерді жүйелік каталогқа орнату..."
mkdir -p ~/.fonts
cp fonts/*.ttf ~/.fonts/
fc-cache -f ~/.fonts

echo "2/4 — Қазақша тасымалдау үлгісін жүктеу (CTAN hyph-utf8)..."
TMPDIR=$(mktemp -d)
curl -sL -o "$TMPDIR/hyph-utf8.tds.zip" "https://mirrors.ctan.org/install/language/hyph-utf8.tds.zip"
mkdir -p "$TMPDIR/extracted"
unzip -o -q "$TMPDIR/hyph-utf8.tds.zip" \
  "tex/generic/hyph-utf8/patterns/tex/hyph-kk.tex" \
  "tex/generic/hyph-utf8/loadhyph/loadhyph-kk.tex" \
  -d "$TMPDIR/extracted"

TEXMFLOCAL=$(kpsewhich -var-value TEXMFLOCAL)
mkdir -p "$TEXMFLOCAL/tex/generic/hyph-utf8/patterns/tex"
mkdir -p "$TEXMFLOCAL/tex/generic/hyph-utf8/loadhyph"
cp "$TMPDIR/extracted/tex/generic/hyph-utf8/patterns/tex/hyph-kk.tex" \
   "$TEXMFLOCAL/tex/generic/hyph-utf8/patterns/tex/"
cp "$TMPDIR/extracted/tex/generic/hyph-utf8/loadhyph/loadhyph-kk.tex" \
   "$TEXMFLOCAL/tex/generic/hyph-utf8/loadhyph/"
texhash "$TEXMFLOCAL"
rm -rf "$TMPDIR"

echo "3/4 — Тілді language.dat-қа тіркеу..."
LANGDAT="$(kpsewhich language.dat)"
if ! grep -q "^kazakh " "$LANGDAT"; then
  echo "kazakh loadhyph-kk.tex" | sudo tee -a "$LANGDAT" > /dev/null
else
  echo "   (тіркелген, өткізіп жіберілді)"
fi

echo "4/4 — XeLaTeX форматын қайта құрастыру..."
sudo fmtutil-sys --byfmt xelatex

echo ""
echo "Дайын! Тексеру үшін:"
echo "  cd sizes && xelatex five-by-eight.tex"
